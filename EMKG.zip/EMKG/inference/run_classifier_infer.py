"""
  This script provides an example to wrap UER-py for classification inference.
"""
import sys
import os
import torch
import argparse
import collections
import torch.nn as nn
import pkuseg
uer_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.append(uer_dir)

from uer.utils.constants import *
from uer.utils import *
from uer.utils.config import load_hyperparam
from uer.utils.seed import set_seed
from uer.model_loader import load_model
from uer.opts import infer_opts, tokenizer_opts
from finetune.run_classifier import Classifier

def build_injector(kg_path):
    stopwords_file = open('/hdd/cyh/UER-py-master/datasets/stopwords.txt', 'r', encoding='utf-8')
    stopwords = stopwords_file.readlines()
    knowledge_graph_file = open(kg_path, 'r', encoding='utf-8')
    knowledge_graph = knowledge_graph_file.readlines()
    search_table = {}
    never_split_tags = ['[PAD]', '[UNK]', '[CLS]', '[SEP]', '[MASK]']
    for line in knowledge_graph:
        head_index = line.find(" ")
        head = line[:head_index]
        relation_index = line.find(" ", 2)
        relation = line[head_index + 1:relation_index]
        tail = line[relation_index + 1:]
        value = relation + tail
        if head in search_table.keys():
            search_table[head].add(value)
        else:
            search_table[head] = set([value])
    segment_vocab = stopwords + list(search_table.keys()) + never_split_tags
    tokenizer = pkuseg.pkuseg(model_name='default', postag=False, user_dict=segment_vocab)
    return tokenizer, search_table

def inject_knowledge_from_kg(tokenizer, search_table, target, text):
    splitted_text = tokenizer.cut(text)
    extended_target = [target]
    # 注入知识到target
    # for token in splitted_text:
    #     stable_knowledge = list(search_table.get(target, []))
    #     for stable in stable_knowledge:
    #         stable = stable.replace('\n', '')
    #         stable_index = stable.find(' ')
    #         stable_relation = stable[:stable_index]
    #         stable_tail = stable[stable_index + 1:]
    #         if token == stable_tail:
    #             if stable_relation in extended_target and stable_tail in extended_target:
    #                 continue
    #             extended_target.append(stable_relation)
    #             extended_target.append(stable_tail)
    #             extended_target.append('，')
    #注入知识到text
    support_sent = ['已知', ':']
    for token in splitted_text:
        extra_knowledge = list(search_table.get(token, []))
        for knowledge in extra_knowledge:
            knowledge = knowledge.replace('\n', '')
            knowledge_index = knowledge.find(' ')
            knowledge_relation = knowledge[:knowledge_index]
            knowledge_tail = knowledge[knowledge_index + 1:]
            if knowledge_tail in splitted_text:
                if knowledge_relation in splitted_text and knowledge_tail in splitted_text:
                    continue
                support_sent.append(token)
                support_sent.append(knowledge_relation)
                support_sent.append(knowledge_tail)
                support_sent.append('，')
    return extended_target, support_sent

def batch_loader(batch_size, src, seg):
    instances_num = src.size()[0]
    for i in range(instances_num // batch_size):
        src_batch = src[i * batch_size : (i + 1) * batch_size, :]
        seg_batch = seg[i * batch_size : (i + 1) * batch_size, :]
        yield src_batch, seg_batch
    if instances_num > instances_num // batch_size * batch_size:
        src_batch = src[instances_num // batch_size * batch_size :, :]
        seg_batch = seg[instances_num // batch_size * batch_size :, :]
        yield src_batch, seg_batch


def read_dataset(args, path):
    dataset, columns = [], {}
    kg_path = '/hdd/cyh/UER-py-master/datasets/taiwan.spo'
    tokenizer, search_table = build_injector(kg_path)
    with open(path, mode="r", encoding="utf-8") as f:
        for line_id, line in enumerate(f):
            if line_id == 0:
                line = line.rstrip("\r\n").split("\t")
                for i, column_name in enumerate(line):
                    columns[column_name] = i
                continue
            line = line.rstrip("\r\n").split("\t")
            if "target" not in columns:  # Sentence classification.
                text_a = line[columns["text_a"]]
                src = args.tokenizer.convert_tokens_to_ids([CLS_TOKEN] + args.tokenizer.tokenize(text_a) + [SEP_TOKEN])
                seg = [1] * len(src)
            else:  # Sentence pair classification.
                text_a, target = line[columns["text_a"]], line[columns["target"]]
                extended_target, support_sent = inject_knowledge_from_kg(tokenizer, search_table, target, text_a)
                text_b = ''.join(support_sent)
                src_a = args.tokenizer.convert_tokens_to_ids([CLS_TOKEN] + args.tokenizer.tokenize(text_b) + [SEP_TOKEN] + args.tokenizer.tokenize(text_a) + [SEP_TOKEN])
                src_b = args.tokenizer.convert_tokens_to_ids(args.tokenizer.tokenize(target) + [SEP_TOKEN])
                src = src_a + src_b
                seg = [1] * len(src_a) + [2] * len(src_b)
            if len(src) > args.seq_length:
                src = src[: args.seq_length]
                seg = seg[: args.seq_length]
            PAD_ID = args.tokenizer.convert_tokens_to_ids([PAD_TOKEN])[0]
            while len(src) < args.seq_length:
                src.append(PAD_ID)
                seg.append(0)
            dataset.append((src, seg))

    return dataset


def main():
    parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)

    infer_opts(parser)

    parser.add_argument("--labels_num", type=int, required=True,
                        help="Number of prediction labels.")

    tokenizer_opts(parser)

    parser.add_argument("--output_logits", action="store_true", help="Write logits to output file.")
    parser.add_argument("--output_prob", action="store_true", help="Write probabilities to output file.")

    args = parser.parse_args()

    # Load the hyperparameters from the config file.
    args = load_hyperparam(args)

    # Build tokenizer.
    args.tokenizer = str2tokenizer[args.tokenizer](args)

    # Build classification model and load parameters.
    args.soft_targets, args.soft_alpha = False, False
    model = Classifier(args)
    model = load_model(model, args.load_model_path)

    # For simplicity, we use DataParallel wrapper to use multiple GPUs.
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = model.to(device)
    if torch.cuda.device_count() > 1:
        print("{} GPUs are available. Let's use them.".format(torch.cuda.device_count()))
        model = torch.nn.DataParallel(model)

    dataset = read_dataset(args, args.test_path)

    src = torch.LongTensor([sample[0] for sample in dataset])
    seg = torch.LongTensor([sample[1] for sample in dataset])

    batch_size = args.batch_size
    instances_num = src.size()[0]

    print("The number of prediction instances: ", instances_num)

    model.eval()

    with open(args.prediction_path, mode="w", encoding="utf-8") as f:
        f.write("label")
        if args.output_logits:
            f.write("\t" + "logits")
        if args.output_prob:
            f.write("\t" + "prob")
        f.write("\n")
        for i, (src_batch, seg_batch) in enumerate(batch_loader(batch_size, src, seg)):
            src_batch = src_batch.to(device)
            seg_batch = seg_batch.to(device)
            with torch.no_grad():
                _, logits = model(src_batch, None, seg_batch)

            pred = torch.argmax(logits, dim=1)
            pred = pred.cpu().numpy().tolist()
            prob = nn.Softmax(dim=1)(logits)
            logits = logits.cpu().numpy().tolist()
            prob = prob.cpu().numpy().tolist()

            for j in range(len(pred)):
                f.write(str(pred[j]))
                if args.output_logits:
                    f.write("\t" + " ".join([str(v) for v in logits[j]]))
                if args.output_prob:
                    f.write("\t" + " ".join([str(v) for v in prob[j]]))
                f.write("\n")


if __name__ == "__main__":
    main()
